#include <phidget21.h>

#ifndef MOTORCONTROL_H_
#define MOTORCONTROL_H_

	void init();
	void close();

	void setVelocity(int motor, double velocity);
	void setAcceleration(int motor, double velocity);


#endif /* MOTORCONTROL_H_ */
